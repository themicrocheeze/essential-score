const team1nameRep = nodecg.Replicant('team1name', {defaultValue: "BLU"});
const team2nameRep = nodecg.Replicant('team2name', {defaultValue: "RED"});



function setTeam1Name(){
    team1nameRep.value = team1nameinput.value;
}