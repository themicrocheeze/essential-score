'use strict';

module.exports = function (nodecg) {
	nodecg.log.info('ESSENTIAL SCORE VERSION 1.0')
	nodecg.log.info(`To edit me, open "${__filename}" in your favorite text editor or IDE.`);
};
